-- Creazione del database
CREATE DATABASE ToysGroup;
USE ToysGroup;

-- Creazione della tabella REGION
CREATE TABLE REGION (
    RegionID INT AUTO_INCREMENT PRIMARY KEY,
    RegionName VARCHAR(100) NOT NULL
);

-- Creazione della tabella COUNTRY
CREATE TABLE COUNTRY (
    CountryID INT AUTO_INCREMENT PRIMARY KEY,
    CountryName VARCHAR(100) NOT NULL,
    RegionID INT NOT NULL,
    CONSTRAINT fk_country_region FOREIGN KEY (RegionID) REFERENCES REGION(RegionID)
);

-- Creazione della tabella CATEGORY
CREATE TABLE CATEGORY (
    CategoryID INT AUTO_INCREMENT PRIMARY KEY,
    CategoryName VARCHAR(100) NOT NULL
);

-- Creazione della tabella PRODUCT
CREATE TABLE PRODUCT (
    ProductID INT AUTO_INCREMENT PRIMARY KEY,
    ProductName VARCHAR(100) NOT NULL,
    CategoryID INT NOT NULL,
    CONSTRAINT fk_product_category FOREIGN KEY (CategoryID) REFERENCES CATEGORY(CategoryID)
);

-- Creazione della tabella SALES
CREATE TABLE SALES (
    SalesID INT AUTO_INCREMENT PRIMARY KEY,
    OrderDate DATE NOT NULL,
    Quantity INT NOT NULL,
    UnitePrice DECIMAL(10,2) NOT NULL,
    TotalPrice DECIMAL(10, 2) NOT NULL,
    ProductID INT NOT NULL,
    CountryID INT NOT NULL,
    CONSTRAINT fk_sales_product FOREIGN KEY (ProductID) REFERENCES PRODUCT(ProductID),
    CONSTRAINT fk_sales_country FOREIGN KEY (CountryID) REFERENCES COUNTRY(CountryID)
);




-- Popolamento della tabella REGION
INSERT INTO REGION (RegionName) VALUES
('North America'),
('Europe'),
('Asia'),
('South America');

-- Popolamento della tabella COUNTRY
INSERT INTO COUNTRY (CountryName, RegionID) VALUES
('United States', 1),
('Canada', 1),
('Germany', 2),
('Italy', 2),
('Japan', 3),
('China', 3),
('Brazil', 4);

-- Popolamento della tabella CATEGORY
INSERT INTO CATEGORY (CategoryName) VALUES
('Peluche'),
('Puzzle'),
('Giochi di società'),
('Action Figures'),
('Giocattoli educativi');

-- Popolamento della tabella PRODUCT
INSERT INTO PRODUCT (ProductName, CategoryID) VALUES
('Orso Teddy', 1),
('Coniglio Peluche', 1),
('Puzzle 500 pezzi - Paesaggio', 2),
('Puzzle 1000 pezzi - Mappa del mondo', 2),
('Monopoli', 3),
('Risiko', 3),
('Action Figure - Supereroe', 4),
('Action Figure - Robot', 4),
('Gioco memoria per bambini', 5),
('Kit scientifico per bambini', 5),
('Cubo di Rubik', 5),
('Dinosauro Peluche', 1),
('Puzzle 3D - Torre Eiffel', 2),
('Gioco di ruolo - Fantasy', 3),
('Action Figure - Spadaccino', 4);


INSERT INTO SALES (OrderDate, Quantity, UnitePrice, TotalPrice, ProductID, CountryID) VALUES
('2023-01-01', 5, 15.99, 79.95, 1, 1),
('2025-01-02', 4, 12.99, 51.96, 2, 2),
('2024-01-03', 3, 20.00, 60.00, 3, 3),
('2025-01-04', 6, 22.50, 135.00, 4, 4),
('2022-01-05', 3, 30.00, 90.00, 5, 5),
('2022-01-06', 5, 35.00, 175.00, 6, 1),
('2025-01-07', 8, 18.50, 148.00, 7, 2),
('2024-01-08', 4, 25.00, 100.00, 8, 3),
('2025-01-09', 6, 14.99, 89.94, 9, 4),
('2025-01-10', 3, 40.00, 120.00, 10, 5),
('2023-01-11', 10, 10.00, 100.00, 11, 1),
('2025-01-12', 5, 19.99, 99.95, 12, 2),
('2024-01-13', 4, 50.00, 200.00, 13, 3),
('2023-01-14', 5, 45.00, 225.00, 14, 4),
('2025-01-15', 7, 25.00, 175.00, 15, 5);


-- 1)	Verificare che i campi definiti come PK siano univoci. In altre parole, scrivi una query per determinare l’univocità dei valori di ciascuna PK (una query per tabella implementata).

SELECT RegionID, COUNT(*) 
FROM REGION
GROUP BY RegionID
HAVING COUNT(*) > 1;




SELECT CountryID, COUNT(*) 
FROM COUNTRY
GROUP BY CountryID
HAVING COUNT(*) > 1;




SELECT CategoryID, COUNT(*) 
FROM CATEGORY
GROUP BY CategoryID
HAVING COUNT(*) > 1;



SELECT ProductID, COUNT(*) 
FROM PRODUCT
GROUP BY ProductID
HAVING COUNT(*) > 1;


SELECT SalesID, COUNT(*) 
FROM SALES
GROUP BY SalesID
HAVING COUNT(*) > 1;


-- 2)	Esporre l’elenco delle transazioni indicando nel result set il codice documento, la data, il nome del prodotto, 
-- la categoria del prodotto, il nome dello stato, il nome della regione di vendita e un campo booleano valorizzato in base alla condizione che siano passati più di 180 giorni dalla data vendita 
-- o meno (>180 -> True, <= 180 -> False)

SELECT 
    S.SalesID AS CodiceDocumento,
    S.OrderDate AS DataVendita,
    P.ProductName AS NomeProdotto,
    C.CategoryName AS CategoriaProdotto,
    CO.CountryName AS NomeStato,
    R.RegionName AS NomeRegione,
    CASE 
        WHEN DATEDIFF(CURDATE(), S.OrderDate) > 180 THEN 1
        ELSE 0
    END AS Oltre180Giorni
FROM 
    SALES S
JOIN 
    PRODUCT P ON S.ProductID = P.ProductID
JOIN 
    CATEGORY C ON P.CategoryID = C.CategoryID
JOIN 
    COUNTRY CO ON S.CountryID = CO.CountryID
JOIN 
    REGION R ON CO.RegionID = R.RegionID;
    
    
  --  3)Esporre l’elenco dei prodotti che hanno venduto, 
  -- in totale, una quantità maggiore della media delle vendite realizzate nell’ultimo anno censito.
  -- (ogni valore della condizione deve risultare da una query e non deve essere inserito a mano). Nel result set devono comparire solo il codice prodotto e il totale venduto.
    
    SELECT 
    p.ProductID,
    SUM(s.Quantity) AS TotalQuantitySold
FROM 
    SALES s
JOIN 
    PRODUCT p ON s.ProductID = p.ProductID
WHERE 
    YEAR(s.OrderDate) = (SELECT MAX(YEAR(OrderDate)) FROM SALES) -- ultimo anno censito
GROUP BY 
    p.ProductID
HAVING 
    SUM(s.Quantity) > (SELECT AVG(TotalQuantity) 
                        FROM (SELECT SUM(Quantity) AS TotalQuantity 
                              FROM SALES 
                              WHERE YEAR(OrderDate) = (SELECT MAX(YEAR(OrderDate)) FROM SALES)
                              GROUP BY ProductID) AS yearly_sales);
                              
                              
 -- 4)Esporre l’elenco dei soli prodotti venduti e per ognuno di questi il fatturato totale per anno.                             
                              
 SELECT 
    p.ProductID,
    YEAR(s.OrderDate) AS SalesYear,
    SUM(s.Quantity * s.TotalPrice) AS TotalRevenue
FROM 
    SALES s
JOIN 
    PRODUCT p ON s.ProductID = p.ProductID
GROUP BY 
    p.ProductID, YEAR(s.OrderDate)
ORDER BY 
    p.ProductID, SalesYear;
    
    
                             
-- 5)	Esporre il fatturato totale per stato per anno. Ordina il risultato per data e per fatturato decrescente.


SELECT 
    c.CountryID,
    YEAR(s.OrderDate) AS SalesYear,
    SUM(s.Quantity * s.TotalPrice) AS TotalRevenue
FROM 
    SALES s
JOIN 
    COUNTRY c ON s.CountryID = c.CountryID
GROUP BY 
    c.CountryID, YEAR(s.OrderDate)
ORDER BY 
    SalesYear ASC, TotalRevenue DESC;
    
    
    select*from product;

-- 6)Rispondere alla seguente domanda: qual è la categoria di articoli maggiormente richiesta dal mercato?



SELECT 
    c.CategoryName,
    SUM(s.Quantity) AS TotalQuantitySold
FROM 
    SALES s
JOIN 
    PRODUCT p ON s.ProductID = p.ProductID
JOIN 
    CATEGORY c ON p.CategoryID = c.CategoryID
GROUP BY 
    c.CategoryName
ORDER BY 
    TotalQuantitySold DESC
LIMIT 1;


-- 7)	Rispondere alla seguente domanda: quali sono i prodotti invenduti? Proponi due approcci risolutivi differenti.

SELECT 
    p.ProductID,
    p.ProductName
FROM 
    PRODUCT p
LEFT JOIN 
    SALES s ON p.ProductID = s.ProductID
WHERE 
    s.ProductID IS NULL;





SELECT 
    p.ProductID,
    p.ProductName
FROM 
    PRODUCT p
LEFT JOIN 
    SALES s ON p.ProductID = s.ProductID
GROUP BY 
    p.ProductID
HAVING 
    SUM(s.Quantity) = 0 OR SUM(s.Quantity) IS NULL;
    
    
  --  8)Creare una vista sui prodotti in modo tale da esporre una “versione denormalizzata” delle informazioni utili (codice prodotto, nome prodotto, nome categoria)
    
  CREATE VIEW ProductCategoryView AS
SELECT 
    p.ProductID AS ProductCode,
    p.ProductName AS ProductName,
    c.CategoryName AS CategoryName
FROM 
    PRODUCT p
JOIN 
    CATEGORY c ON p.CategoryID = c.CategoryID;
  
SHOW TABLES;


SELECT * FROM ProductCategoryView;



-- 9)Creare una vista per le informazioni geografiche

CREATE VIEW GeographyView AS
SELECT 
    r.RegionName AS RegionName,
    c.CountryName AS CountryName
FROM 
    REGION r
JOIN 
    COUNTRY c ON r.RegionID = c.RegionID;

select*from GeographyView;

